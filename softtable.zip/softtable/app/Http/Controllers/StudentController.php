<?php

namespace App\Http\Controllers;

use App\Models\Mark;
use App\Models\StudentInfo;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function create(){
        return view('student.welcome');
    }

    public function thanks(){
        return view('student.thanks');
    }

    public function store(Request $request ){
        // return $request;
        $user = new Mark();

        $user->name=$request->name;
        $user->marks=$request->marks;

        $user->save();

        // second table;
        $user = new StudentInfo();

        $user->name=$request->name;
        $user->class=$request->class;
        $user->age=$request->age;

        $user->save();
        // return $request;



        return back()->withSuccess('success ');


        return redirect('thanks');
    }
}

