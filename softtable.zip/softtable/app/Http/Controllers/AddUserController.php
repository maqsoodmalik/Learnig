<?php

namespace App\Http\Controllers;


use App\Models\AddUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AddUserController extends Controller
{
    public function index(){
        $user = AddUser::get();
        return view('user.index',get_defined_vars());
    }
    public function create(){
        return view('user.create');
    }

    public function store(Request $request ){
    
        $request->validate([


            'email'=> 'required|unique:add_users,email',
            'password'=>'required',
            // 'phone'=>'required',
            'phone' => 'required|unique:add_users,phone|numeric',
        ]);

        $imageName = time().'.'.$request->image->extension();
        // return $imageName;
        $request->image->move(public_path('user'),$imageName);
        // return "file saved";
        $user = new AddUser();
        $user->image=$imageName;
        $user->email=$request->email;
        $user->password=$request->password;
        $user->phone=$request->phone;
        $user->save();
        return back()->withSuccess('success ');

    }

    public function edit($id){
        //   dd($id);
        $user=AddUser::where('id', $id)->first();

        return view('user.edit',['user'=>$user]);

    }


    public function update(Request $request, $id){
        //   dd($request->all());
        //   dd($id);
        $request->validate([
            'email'=>'required',
            'password'=>'required',
            'phone'=>'required',
            'image'=>'nullable'
        ]);

        $user=AddUser::where('id', $id)->first();
        if(isset($request->image)){
            $imageName = time().'.'.$request->image->extension();
        $request->image->move(public_path('user'),$imageName);
        $user->image=$imageName;
        }

        $user->phone=$request->phone;
        $user->email=$request->email;
        $user->password=$request->password;
        $user->save();
        return back()->withSuccess('product updated successfyly');

        }

        public function destroy($id){
            // return $id;


            $user=AddUser::where('id', $id)->first();
            $user->delete();
            // return $user;
            return back()->withSuccess('product deleted successfully ');
        }



}
