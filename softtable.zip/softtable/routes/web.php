<?php

use App\Http\Controllers\AddUserController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/',[AddUserController::class,'index']);
// Route::get('/user/create',[AddUserController::class,'create']);
// Route::post('/user/store',[AddUserController::class,'store']);
// Route::get('/user/{id}/edit',[AddUserController::class,'edit']);
// Route::put('/user/{id}/update',[AddUserController::class,'update']);
// Route::get('/user/{id}/delete',[AddUserController::class,'destroy']);


// Route::get('/send-mail', function () {

//     $details = [
//         "hi"
//         // 'title' => 'Mail from ItSolutionStuff.com',
//         // 'body' => 'This is for testing email using smtp'
//     ];

//     Mail::to('developerbcb2@gmail.com ')->send(new \App\Mail\MyTestMail($details));

//     // dd("Email is Sent.");
// });


Route::get('/',[StudentController::class,'create']);
Route::post('/store',[StudentController::class,'store']);
Route::get('/thanks',[StudentController::class,'thanks']);

